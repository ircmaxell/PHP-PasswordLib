<?php
/**
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 * @version    Build 0.0.8
 */

namespace CryptLib\Key;

/**
 *
 * @author ircmaxell
 */
interface Symmetric extends Key {

    public function getKey();

    public function saveKey($filename);

}
